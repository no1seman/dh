package main

import (
	"context"
	"crypto/tls"
	"crypto/x509"
	"fmt"
	"log"
	"os"
	"sync"
	"time"

	clientv3 "go.etcd.io/etcd/client/v3"
	"google.golang.org/grpc"
	"google.golang.org/grpc/keepalive"
	"google.golang.org/grpc/metadata"
)

// ServerConfig holds configuration for each etcd server
type ServerConfig struct {
	Endpoint   string
	CACertPath string
	ClientCert string
	ClientKey  string
	ServerName string
	ACLHeader  string
}

// ClientManager manages etcd client connections with reconnection logic
type ClientManager struct {
	config      ServerConfig
	client      *clientv3.Client
	mu          sync.RWMutex
	isConnected bool
	stopCh      chan struct{}
	reconnectCh chan struct{}
}

func loadTLSConfig(caCertPath, clientCert, clientKey, serverName string) (*tls.Config, error) {
	// Load CA certificate
	caCert, err := os.ReadFile(caCertPath)
	if err != nil {
		return nil, fmt.Errorf("failed to read CA certificate: %v", err)
	}

	caCertPool := x509.NewCertPool()
	if !caCertPool.AppendCertsFromPEM(caCert) {
		return nil, fmt.Errorf("failed to parse CA certificate")
	}

	// Load client certificate
	clientCertPair, err := tls.LoadX509KeyPair(clientCert, clientKey)
	if err != nil {
		return nil, fmt.Errorf("failed to load client certificate: %v", err)
	}

	return &tls.Config{
		RootCAs:      caCertPool,
		Certificates: []tls.Certificate{clientCertPair},
		ServerName:   serverName,
	}, nil
}

func createClientForEndpoint(config ServerConfig) (*clientv3.Client, error) {
	tlsConfig, err := loadTLSConfig(config.CACertPath, config.ClientCert, config.ClientKey, config.ServerName)
	if err != nil {
		return nil, fmt.Errorf("failed to create TLS config for %s: %v", config.Endpoint, err)
	}

	clientConfig := clientv3.Config{
		Endpoints:   []string{config.Endpoint},
		DialTimeout: 10 * time.Second,
		TLS:         tlsConfig,
		// Keepalive configuration
		DialKeepAliveTime:    30 * time.Second,
		DialKeepAliveTimeout: 5 * time.Second,
		// Additional gRPC dial options for more granular keepalive control
		DialOptions: []grpc.DialOption{
			grpc.WithKeepaliveParams(keepalive.ClientParameters{
				Time:                10 * time.Second, // Send keepalive pings every 10 seconds
				Timeout:             3 * time.Second,  // Wait 3 seconds for ping ack before considering the connection dead
				PermitWithoutStream: true,             // Allow keepalive pings even when there are no active RPCs
			}),
		},
		// Auto-sync endpoints periodically
		AutoSyncInterval: 30 * time.Second,
	}

	return clientv3.New(clientConfig)
}

// NewClientManager creates a new client manager with reconnection capabilities
func NewClientManager(config ServerConfig) *ClientManager {
	return &ClientManager{
		config:      config,
		stopCh:      make(chan struct{}),
		reconnectCh: make(chan struct{}, 1),
	}
}

// Connect establishes initial connection
func (cm *ClientManager) Connect() error {
	client, err := createClientForEndpoint(cm.config)
	if err != nil {
		return err
	}

	cm.mu.Lock()
	cm.client = client
	cm.isConnected = true
	cm.mu.Unlock()

	log.Printf("Successfully connected to %s", cm.config.Endpoint)

	// Start health monitoring goroutine
	go cm.healthMonitor()

	return nil
}

// healthMonitor continuously monitors connection health and triggers reconnection if needed
func (cm *ClientManager) healthMonitor() {
	ticker := time.NewTicker(15 * time.Second)
	defer ticker.Stop()

	for {
		select {
		case <-cm.stopCh:
			return
		case <-ticker.C:
			if !cm.isHealthy() {
				log.Printf("Connection to %s is unhealthy, triggering reconnection", cm.config.Endpoint)
				cm.triggerReconnect()
			}
		case <-cm.reconnectCh:
			cm.reconnect()
		}
	}
}

// isHealthy checks if the connection is healthy
func (cm *ClientManager) isHealthy() bool {
	cm.mu.RLock()
	client := cm.client
	isConnected := cm.isConnected
	cm.mu.RUnlock()

	if !isConnected || client == nil {
		return false
	}

	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()

	// Try to get status to check connectivity
	_, err := client.Status(ctx, cm.config.Endpoint)
	return err == nil
}

// triggerReconnect safely triggers a reconnection attempt
func (cm *ClientManager) triggerReconnect() {
	cm.mu.Lock()
	cm.isConnected = false
	cm.mu.Unlock()

	select {
	case cm.reconnectCh <- struct{}{}:
	default:
		// Channel is full, reconnection already triggered
	}
}

// reconnect attempts to reconnect with exponential backoff
func (cm *ClientManager) reconnect() {
	log.Printf("Starting reconnection process for %s", cm.config.Endpoint)

	// Close existing client if it exists
	cm.mu.Lock()
	if cm.client != nil {
		cm.client.Close()
		cm.client = nil
	}
	cm.isConnected = false
	cm.mu.Unlock()

	backoff := time.Second
	maxBackoff := 60 * time.Second

	for {
		select {
		case <-cm.stopCh:
			return
		default:
		}

		log.Printf("Attempting to reconnect to %s...", cm.config.Endpoint)

		client, err := createClientForEndpoint(cm.config)
		if err != nil {
			log.Printf("Reconnection failed for %s: %v, retrying in %v", cm.config.Endpoint, err, backoff)
			time.Sleep(backoff)

			// Exponential backoff with jitter
			backoff = backoff * 2
			if backoff > maxBackoff {
				backoff = maxBackoff
			}
			continue
		}

		// Test the connection
		ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
		_, err = client.Status(ctx, cm.config.Endpoint)
		cancel()

		if err != nil {
			log.Printf("Connection test failed for %s: %v, retrying in %v", cm.config.Endpoint, err, backoff)
			client.Close()
			time.Sleep(backoff)

			backoff = backoff * 2
			if backoff > maxBackoff {
				backoff = maxBackoff
			}
			continue
		}

		// Successfully reconnected
		cm.mu.Lock()
		cm.client = client
		cm.isConnected = true
		cm.mu.Unlock()

		log.Printf("Successfully reconnected to %s", cm.config.Endpoint)
		return
	}
}

// GetClient returns the current client if connected
func (cm *ClientManager) GetClient() (*clientv3.Client, bool) {
	cm.mu.RLock()
	defer cm.mu.RUnlock()
	return cm.client, cm.isConnected
}

// Close stops the client manager and closes connections
func (cm *ClientManager) Close() {
	close(cm.stopCh)

	cm.mu.Lock()
	if cm.client != nil {
		cm.client.Close()
		cm.client = nil
	}
	cm.isConnected = false
	cm.mu.Unlock()
}

func addACLHeader(ctx context.Context, aclHeader string) context.Context {
	md := metadata.New(map[string]string{
		"acl": aclHeader,
	})
	return metadata.NewOutgoingContext(ctx, md)
}

func testEndpointWithACL(cm *ClientManager) error {
	log.Printf("Testing endpoint: %s", cm.config.Endpoint)

	client, isConnected := cm.GetClient()
	if !isConnected || client == nil {
		return fmt.Errorf("client for %s is not connected", cm.config.Endpoint)
	}

	ctx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
	defer cancel()

	// Add ACL header for this specific endpoint
	ctx = addACLHeader(ctx, cm.config.ACLHeader)

	// Test basic connectivity first
	log.Printf("Testing connectivity to %s...", cm.config.Endpoint)
	status, err := client.Status(ctx, cm.config.Endpoint)
	if err != nil {
		// Trigger reconnection on error
		cm.triggerReconnect()
		return fmt.Errorf("failed to get status from %s: %v", cm.config.Endpoint, err)
	}
	log.Printf("Successfully connected to %s, version: %s", cm.config.Endpoint, status.Version)

	// Create a unique key for this endpoint
	key := fmt.Sprintf("test-key-%s", cm.config.Endpoint)
	value := fmt.Sprintf("test-value-%s-%d", cm.config.Endpoint, time.Now().Unix())

	// Put a key-value pair
	_, err = client.Put(ctx, key, value)
	if err != nil {
		cm.triggerReconnect()
		return fmt.Errorf("failed to put key-value to %s: %v", cm.config.Endpoint, err)
	}
	fmt.Printf("Successfully put to %s: %s = %s\n", cm.config.Endpoint, key, value)

	// Get the value
	resp, err := client.Get(ctx, key)
	if err != nil {
		cm.triggerReconnect()
		return fmt.Errorf("failed to get key from %s: %v", cm.config.Endpoint, err)
	}

	for _, kv := range resp.Kvs {
		fmt.Printf("Retrieved from %s: %s = %s\n", cm.config.Endpoint, string(kv.Key), string(kv.Value))
	}

	return nil
}

func main() {
	// Configure each etcd server with different authorities and ACL headers
	serverConfigs := []ServerConfig{
		{
			Endpoint:   "etcd1:2379",
			CACertPath: "certs/ca1.pem",
			ClientCert: "certs/client1-cert.pem",
			ClientKey:  "certs/client1-key.pem",
			ServerName: "etcd1",
			ACLHeader:  "etcd1-acl-token-12345",
		},
		{
			Endpoint:   "etcd2:2379",
			CACertPath: "certs/ca2.pem",
			ClientCert: "certs/client2-cert.pem",
			ClientKey:  "certs/client2-key.pem",
			ServerName: "etcd2",
			ACLHeader:  "etcd2-acl-token-67890",
		},
		{
			Endpoint:   "etcd3:2379",
			CACertPath: "certs/ca3.pem",
			ClientCert: "certs/client3-cert.pem",
			ClientKey:  "certs/client3-key.pem",
			ServerName: "etcd3",
			ACLHeader:  "etcd3-acl-token-abcde",
		},
	}

	log.Println("Starting etcd client tests with TLS, keepalive, and reconnection logic")

	// Create client managers for each endpoint
	var clientManagers []*ClientManager

	// Initialize and connect all client managers
	for _, config := range serverConfigs {
		cm := NewClientManager(config)
		if err := cm.Connect(); err != nil {
			log.Printf("Failed to connect to %s: %v", config.Endpoint, err)
			continue
		}
		clientManagers = append(clientManagers, cm)
	}

	// Ensure cleanup on exit
	defer func() {
		log.Println("Closing all client connections...")
		for _, cm := range clientManagers {
			cm.Close()
		}
	}()

	// Test each endpoint individually with its specific ACL header
	for _, cm := range clientManagers {
		if err := testEndpointWithACL(cm); err != nil {
			log.Printf("Error testing endpoint %s: %v", cm.config.Endpoint, err)
		} else {
			log.Printf("Successfully tested endpoint: %s", cm.config.Endpoint)
		}
		time.Sleep(1 * time.Second) // Small delay between tests
	}

	// Test cluster-wide operations using the first available client
	if len(clientManagers) > 0 {
		log.Println("Testing cluster-wide operations...")
		firstManager := clientManagers[0]
		client, isConnected := firstManager.GetClient()

		if !isConnected || client == nil {
			log.Printf("First client is not connected, skipping cluster operations")
		} else {
			ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
			defer cancel()

			// List cluster members
			memberResp, err := client.MemberList(ctx)
			if err != nil {
				log.Printf("Warning: Failed to list members: %v", err)
			} else {
				fmt.Println("\nCluster members:")
				for _, member := range memberResp.Members {
					fmt.Printf("  ID: %x, Name: %s, URLs: %v\n", member.ID, member.Name, member.ClientURLs)
				}
			}
		}
	}

	fmt.Println("\nTLS etcd client test with keepalive and reconnection logic completed!")

	// Keep the program running to demonstrate reconnection capabilities
	log.Println("Program will continue running to demonstrate reconnection capabilities...")
	log.Println("Press Ctrl+C to exit")

	// Run periodic health checks
	ticker := time.NewTicker(30 * time.Second)
	defer ticker.Stop()

	for {
		select {
		case <-ticker.C:
			log.Println("Performing periodic health check on all connections...")
			for _, cm := range clientManagers {
				client, isConnected := cm.GetClient()
				if isConnected && client != nil {
					ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
					_, err := client.Status(ctx, cm.config.Endpoint)
					cancel()

					if err != nil {
						log.Printf("Health check failed for %s: %v", cm.config.Endpoint, err)
					} else {
						log.Printf("Health check passed for %s", cm.config.Endpoint)
					}
				} else {
					log.Printf("Client for %s is not connected", cm.config.Endpoint)
				}
			}
		}
	}
}
