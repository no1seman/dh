package main

import (
	"context"
	"crypto/tls"
	"net"
	"time"

	clientv3 "go.etcd.io/etcd/client/v3"
	"google.golang.org/grpc"
)

func main() {
	// Create different TLS configs for different endpoints
	tlsConfig1 := &tls.Config{
		ServerName: "authority1.example.com",
		// Add certificates for endpoint 1
	}

	tlsConfig2 := &tls.Config{
		ServerName: "authority2.example.com",
		// Add certificates for endpoint 2
	}

	// Create a custom dialer that selects TLS config based on endpoint
	customDialer := func(ctx context.Context, addr string) (net.Conn, error) {
		var tlsConfig *tls.Config

		switch addr {
		case "etcd1.example.com:2379":
			tlsConfig = tlsConfig1
		case "etcd2.example.com:2379":
			tlsConfig = tlsConfig2
		default:
			tlsConfig = &tls.Config{}
		}

		return tls.Dial("tcp", addr, tlsConfig)
	}

	config := clientv3.Config{
		Endpoints:   []string{"etcd1.example.com:2379", "etcd2.example.com:2379"},
		DialTimeout: 5 * time.Second,
		DialOptions: []grpc.DialOption{
			grpc.WithContextDialer(customDialer),
		},
	}

	client, err := clientv3.New(config)
	if err != nil {
		panic(err)
	}
	defer client.Close()
}
