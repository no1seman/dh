#!/bin/bash

# Create certs directory
mkdir -p certs

# Generate CA1 for etcd1 client connections
openssl genrsa -out certs/ca1-key.pem 4096
openssl req -new -x509 -key certs/ca1-key.pem -sha256 -subj "/C=US/ST=CA/O=ETCD1/CN=authority1.example.com" -days 3650 -out certs/ca1.pem

# Generate CA2 for etcd2 client connections
openssl genrsa -out certs/ca2-key.pem 4096
openssl req -new -x509 -key certs/ca2-key.pem -sha256 -subj "/C=US/ST=CA/O=ETCD2/CN=authority2.example.com" -days 3650 -out certs/ca2.pem

# Generate CA3 for etcd3 client connections
openssl genrsa -out certs/ca3-key.pem 4096
openssl req -new -x509 -key certs/ca3-key.pem -sha256 -subj "/C=US/ST=CA/O=ETCD3/CN=authority3.example.com" -days 3650 -out certs/ca3.pem

# Generate common peer CA for all etcd servers
openssl genrsa -out certs/peer-ca-key.pem 4096
openssl req -new -x509 -key certs/peer-ca-key.pem -sha256 -subj "/C=US/ST=CA/O=ETCD-PEER/CN=peer.etcd.cluster" -days 3650 -out certs/peer-ca.pem

# Generate server certificate for etcd1 (client connections)
openssl genrsa -out certs/etcd1-key.pem 4096
openssl req -subj "/C=US/ST=CA/O=ETCD1/CN=etcd1" -sha256 -new -key certs/etcd1-key.pem -out certs/etcd1.csr
echo "subjectAltName=DNS:etcd1,DNS:localhost,IP:127.0.0.1" >> certs/etcd1.ext
echo "extendedKeyUsage=serverAuth,clientAuth" >> certs/etcd1.ext
echo "keyUsage=digitalSignature,keyEncipherment" >> certs/etcd1.ext
openssl x509 -req -days 365 -sha256 -in certs/etcd1.csr -CA certs/ca1.pem -CAkey certs/ca1-key.pem -out certs/etcd1-cert.pem -extfile certs/etcd1.ext -CAcreateserial

# Generate server certificate for etcd2 (client connections)
openssl genrsa -out certs/etcd2-key.pem 4096
openssl req -subj "/C=US/ST=CA/O=ETCD2/CN=etcd2" -sha256 -new -key certs/etcd2-key.pem -out certs/etcd2.csr
echo "subjectAltName=DNS:etcd2,DNS:localhost,IP:127.0.0.1" >> certs/etcd2.ext
echo "extendedKeyUsage=serverAuth,clientAuth" >> certs/etcd2.ext
echo "keyUsage=digitalSignature,keyEncipherment" >> certs/etcd2.ext
openssl x509 -req -days 365 -sha256 -in certs/etcd2.csr -CA certs/ca2.pem -CAkey certs/ca2-key.pem -out certs/etcd2-cert.pem -extfile certs/etcd2.ext -CAcreateserial

# Generate server certificate for etcd3 (client connections)
openssl genrsa -out certs/etcd3-key.pem 4096
openssl req -subj "/C=US/ST=CA/O=ETCD3/CN=etcd3" -sha256 -new -key certs/etcd3-key.pem -out certs/etcd3.csr
echo "subjectAltName=DNS:etcd3,DNS:localhost,IP:127.0.0.1" >> certs/etcd3.ext
echo "extendedKeyUsage=serverAuth,clientAuth" >> certs/etcd3.ext
echo "keyUsage=digitalSignature,keyEncipherment" >> certs/etcd3.ext
openssl x509 -req -days 365 -sha256 -in certs/etcd3.csr -CA certs/ca3.pem -CAkey certs/ca3-key.pem -out certs/etcd3-cert.pem -extfile certs/etcd3.ext -CAcreateserial

# Generate peer certificates for all etcd servers (using common peer CA)
# Peer cert for etcd1
openssl genrsa -out certs/etcd1-peer-key.pem 4096
openssl req -subj "/C=US/ST=CA/O=ETCD-PEER/CN=etcd1" -sha256 -new -key certs/etcd1-peer-key.pem -out certs/etcd1-peer.csr
echo "subjectAltName=DNS:etcd1,DNS:localhost,IP:127.0.0.1" >> certs/etcd1-peer.ext
echo "extendedKeyUsage=serverAuth,clientAuth" >> certs/etcd1-peer.ext
echo "keyUsage=digitalSignature,keyEncipherment" >> certs/etcd1-peer.ext
openssl x509 -req -days 365 -sha256 -in certs/etcd1-peer.csr -CA certs/peer-ca.pem -CAkey certs/peer-ca-key.pem -out certs/etcd1-peer-cert.pem -extfile certs/etcd1-peer.ext -CAcreateserial

# Peer cert for etcd2
openssl genrsa -out certs/etcd2-peer-key.pem 4096
openssl req -subj "/C=US/ST=CA/O=ETCD-PEER/CN=etcd2" -sha256 -new -key certs/etcd2-peer-key.pem -out certs/etcd2-peer.csr
echo "subjectAltName=DNS:etcd2,DNS:localhost,IP:127.0.0.1" >> certs/etcd2-peer.ext
echo "extendedKeyUsage=serverAuth,clientAuth" >> certs/etcd2-peer.ext
echo "keyUsage=digitalSignature,keyEncipherment" >> certs/etcd2-peer.ext
openssl x509 -req -days 365 -sha256 -in certs/etcd2-peer.csr -CA certs/peer-ca.pem -CAkey certs/peer-ca-key.pem -out certs/etcd2-peer-cert.pem -extfile certs/etcd2-peer.ext -CAcreateserial

# Peer cert for etcd3
openssl genrsa -out certs/etcd3-peer-key.pem 4096
openssl req -subj "/C=US/ST=CA/O=ETCD-PEER/CN=etcd3" -sha256 -new -key certs/etcd3-peer-key.pem -out certs/etcd3-peer.csr
echo "subjectAltName=DNS:etcd3,DNS:localhost,IP:127.0.0.1" >> certs/etcd3-peer.ext
echo "extendedKeyUsage=serverAuth,clientAuth" >> certs/etcd3-peer.ext
echo "keyUsage=digitalSignature,keyEncipherment" >> certs/etcd3-peer.ext
openssl x509 -req -days 365 -sha256 -in certs/etcd3-peer.csr -CA certs/peer-ca.pem -CAkey certs/peer-ca-key.pem -out certs/etcd3-peer-cert.pem -extfile certs/etcd3-peer.ext -CAcreateserial

# Generate client certificates for each CA
# Client cert for CA1
openssl genrsa -out certs/client1-key.pem 4096
openssl req -subj "/C=US/ST=CA/O=ETCD1/CN=client1" -new -key certs/client1-key.pem -out certs/client1.csr
echo "extendedKeyUsage=clientAuth" >> certs/client1.ext
echo "keyUsage=digitalSignature,keyEncipherment" >> certs/client1.ext
openssl x509 -req -days 365 -sha256 -in certs/client1.csr -CA certs/ca1.pem -CAkey certs/ca1-key.pem -out certs/client1-cert.pem -extfile certs/client1.ext -CAcreateserial

# Client cert for CA2
openssl genrsa -out certs/client2-key.pem 4096
openssl req -subj "/C=US/ST=CA/O=ETCD2/CN=client2" -new -key certs/client2-key.pem -out certs/client2.csr
echo "extendedKeyUsage=clientAuth" >> certs/client2.ext
echo "keyUsage=digitalSignature,keyEncipherment" >> certs/client2.ext
openssl x509 -req -days 365 -sha256 -in certs/client2.csr -CA certs/ca2.pem -CAkey certs/ca2-key.pem -out certs/client2-cert.pem -extfile certs/client2.ext -CAcreateserial

# Client cert for CA3
openssl genrsa -out certs/client3-key.pem 4096
openssl req -subj "/C=US/ST=CA/O=ETCD3/CN=client3" -new -key certs/client3-key.pem -out certs/client3.csr
echo "extendedKeyUsage=clientAuth" >> certs/client3.ext
echo "keyUsage=digitalSignature,keyEncipherment" >> certs/client3.ext
openssl x509 -req -days 365 -sha256 -in certs/client3.csr -CA certs/ca3.pem -CAkey certs/ca3-key.pem -out certs/client3-cert.pem -extfile certs/client3.ext -CAcreateserial

# Clean up CSR and extension files
rm certs/*.csr certs/*.ext certs/*.srl

echo "Certificates generated successfully!"
echo "Client CA certificates:"
echo "  - certs/ca1.pem (for etcd1 client connections)"
echo "  - certs/ca2.pem (for etcd2 client connections)"
echo "  - certs/ca3.pem (for etcd3 client connections)"
echo "Peer CA certificate:"
echo "  - certs/peer-ca.pem (for all etcd peer connections)"
echo "Server certificates (client connections):"
echo "  - certs/etcd1-cert.pem + certs/etcd1-key.pem"
echo "  - certs/etcd2-cert.pem + certs/etcd2-key.pem"
echo "  - certs/etcd3-cert.pem + certs/etcd3-key.pem"
echo "Peer certificates:"
echo "  - certs/etcd1-peer-cert.pem + certs/etcd1-peer-key.pem"
echo "  - certs/etcd2-peer-cert.pem + certs/etcd2-peer-key.pem"
echo "  - certs/etcd3-peer-cert.pem + certs/etcd3-peer-key.pem"
echo "Client certificates:"
echo "  - certs/client1-cert.pem + certs/client1-key.pem"
echo "  - certs/client2-cert.pem + certs/client2-key.pem"
echo "  - certs/client3-cert.pem + certs/client3-key.pem" 