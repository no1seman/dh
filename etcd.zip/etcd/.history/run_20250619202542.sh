#!/bin/bash

docker-compose up --build
