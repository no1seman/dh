package main

import (
	"context"
	"fmt"
	"log"
	"time"

	clientv3 "go.etcd.io/etcd/client/v3"
)

func main() {
	// Connect to etcd cluster from docker-compose
	// Using service names and internal ports
	config := clientv3.Config{
		Endpoints:   []string{"etcd1:2379", "etcd2:2379", "etcd3:2379"},
		DialTimeout: 5 * time.Second,
	}

	client, err := clientv3.New(config)
	if err != nil {
		log.Fatalf("Failed to connect to etcd: %v", err)
	}
	defer client.Close()

	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()

	// Test the connection by putting and getting a value
	key := "test-key"
	value := "test-value"

	// Put a key-value pair
	_, err = client.Put(ctx, key, value)
	if err != nil {
		log.Fatalf("Failed to put key-value: %v", err)
	}
	fmt.Printf("Successfully put key: %s = %s\n", key, value)

	// Get the value
	resp, err := client.Get(ctx, key)
	if err != nil {
		log.Fatalf("Failed to get key: %v", err)
	}

	for _, kv := range resp.Kvs {
		fmt.Printf("Retrieved key: %s = %s\n", string(kv.Key), string(kv.Value))
	}

	// List cluster members
	memberResp, err := client.MemberList(ctx)
	if err != nil {
		log.Fatalf("Failed to list members: %v", err)
	}

	fmt.Println("Cluster members:")
	for _, member := range memberResp.Members {
		fmt.Printf("  ID: %x, Name: %s, URLs: %v\n", member.ID, member.Name, member.ClientURLs)
	}

	fmt.Println("etcd client test completed successfully!")
}
