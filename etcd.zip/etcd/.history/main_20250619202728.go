package main

import (
	"context"
	"crypto/tls"
	"crypto/x509"
	"fmt"
	"log"
	"net"
	"os"
	"time"

	clientv3 "go.etcd.io/etcd/client/v3"
	"google.golang.org/grpc"
	"google.golang.org/grpc/metadata"
)

// ServerConfig holds configuration for each etcd server
type ServerConfig struct {
	Endpoint   string
	CACertPath string
	ClientCert string
	ClientKey  string
	ServerName string
	ACLHeader  string
}

func loadTLSConfig(caCertPath, clientCert, clientKey, serverName string) (*tls.Config, error) {
	// Load CA certificate
	caCert, err := os.ReadFile(caCertPath)
	if err != nil {
		return nil, fmt.Errorf("failed to read CA certificate: %v", err)
	}

	caCertPool := x509.NewCertPool()
	if !caCertPool.AppendCertsFromPEM(caCert) {
		return nil, fmt.Errorf("failed to parse CA certificate")
	}

	// Load client certificate
	clientCertPair, err := tls.LoadX509KeyPair(clientCert, clientKey)
	if err != nil {
		return nil, fmt.Errorf("failed to load client certificate: %v", err)
	}

	return &tls.Config{
		RootCAs:      caCertPool,
		Certificates: []tls.Certificate{clientCertPair},
		ServerName:   serverName,
	}, nil
}

func createCustomDialer(configs map[string]ServerConfig) func(context.Context, string) (net.Conn, error) {
	return func(ctx context.Context, addr string) (net.Conn, error) {
		config, exists := configs[addr]
		if !exists {
			return nil, fmt.Errorf("no configuration found for endpoint: %s", addr)
		}

		tlsConfig, err := loadTLSConfig(config.CACertPath, config.ClientCert, config.ClientKey, config.ServerName)
		if err != nil {
			return nil, fmt.Errorf("failed to create TLS config for %s: %v", addr, err)
		}

		return tls.Dial("tcp", addr, tlsConfig)
	}
}

func createClientWithACL(serverConfigs map[string]ServerConfig) (*clientv3.Client, error) {
	endpoints := make([]string, 0, len(serverConfigs))
	for endpoint := range serverConfigs {
		endpoints = append(endpoints, endpoint)
	}

	customDialer := createCustomDialer(serverConfigs)

	config := clientv3.Config{
		Endpoints:   endpoints,
		DialTimeout: 10 * time.Second,
		DialOptions: []grpc.DialOption{
			grpc.WithContextDialer(customDialer),
		},
	}

	return clientv3.New(config)
}

func addACLHeader(ctx context.Context, endpoint string, serverConfigs map[string]ServerConfig) context.Context {
	config, exists := serverConfigs[endpoint]
	if !exists {
		log.Printf("Warning: No ACL header configuration found for endpoint: %s", endpoint)
		return ctx
	}

	md := metadata.New(map[string]string{
		"acl": config.ACLHeader,
	})
	return metadata.NewOutgoingContext(ctx, md)
}

func testEndpointWithACL(client *clientv3.Client, endpoint string, serverConfigs map[string]ServerConfig) error {
	log.Printf("Testing endpoint: %s", endpoint)

	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()

	// Add ACL header for this specific endpoint
	ctx = addACLHeader(ctx, endpoint, serverConfigs)

	// Create a unique key for this endpoint
	key := fmt.Sprintf("test-key-%s", endpoint)
	value := fmt.Sprintf("test-value-%s-%d", endpoint, time.Now().Unix())

	// Put a key-value pair
	_, err := client.Put(ctx, key, value)
	if err != nil {
		return fmt.Errorf("failed to put key-value to %s: %v", endpoint, err)
	}
	fmt.Printf("Successfully put to %s: %s = %s\n", endpoint, key, value)

	// Get the value
	resp, err := client.Get(ctx, key)
	if err != nil {
		return fmt.Errorf("failed to get key from %s: %v", endpoint, err)
	}

	for _, kv := range resp.Kvs {
		fmt.Printf("Retrieved from %s: %s = %s\n", endpoint, string(kv.Key), string(kv.Value))
	}

	return nil
}

func main() {
	// Configure each etcd server with different authorities and ACL headers
	serverConfigs := map[string]ServerConfig{
		"etcd1:2379": {
			Endpoint:   "etcd1:2379",
			CACertPath: "/tmp/certs/ca1.pem",
			ClientCert: "/tmp/certs/client1-cert.pem",
			ClientKey:  "/tmp/certs/client1-key.pem",
			ServerName: "etcd1",
			ACLHeader:  "etcd1-acl-token-12345",
		},
		"etcd2:2379": {
			Endpoint:   "etcd2:2379",
			CACertPath: "/tmp/certs/ca2.pem",
			ClientCert: "/tmp/certs/client2-cert.pem",
			ClientKey:  "/tmp/certs/client2-key.pem",
			ServerName: "etcd2",
			ACLHeader:  "etcd2-acl-token-67890",
		},
		"etcd3:2379": {
			Endpoint:   "etcd3:2379",
			CACertPath: "/tmp/certs/ca3.pem",
			ClientCert: "/tmp/certs/client3-cert.pem",
			ClientKey:  "/tmp/certs/client3-key.pem",
			ServerName: "etcd3",
			ACLHeader:  "etcd3-acl-token-abcde",
		},
	}

	// Create etcd client with custom TLS configuration
	client, err := createClientWithACL(serverConfigs)
	if err != nil {
		log.Fatalf("Failed to connect to etcd: %v", err)
	}
	defer client.Close()

	log.Println("Connected to etcd cluster with TLS and different authorities")

	// Test each endpoint individually with its specific ACL header
	for endpoint := range serverConfigs {
		if err := testEndpointWithACL(client, endpoint, serverConfigs); err != nil {
			log.Printf("Error testing endpoint %s: %v", endpoint, err)
		} else {
			log.Printf("Successfully tested endpoint: %s", endpoint)
		}
		time.Sleep(1 * time.Second) // Small delay between tests
	}

	// Test cluster-wide operations
	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()

	// List cluster members
	memberResp, err := client.MemberList(ctx)
	if err != nil {
		log.Printf("Warning: Failed to list members: %v", err)
	} else {
		fmt.Println("\nCluster members:")
		for _, member := range memberResp.Members {
			fmt.Printf("  ID: %x, Name: %s, URLs: %v\n", member.ID, member.Name, member.ClientURLs)
		}
	}

	fmt.Println("\nTLS etcd client test with different authorities and ACL headers completed!")
}
