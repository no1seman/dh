package main

import (
	"context"
	"crypto/tls"
	"crypto/x509"
	"fmt"
	"log"
	"os"
	"time"

	clientv3 "go.etcd.io/etcd/client/v3"
	"google.golang.org/grpc/metadata"
)

// ServerConfig holds configuration for each etcd server
type ServerConfig struct {
	Endpoint   string
	CACertPath string
	ClientCert string
	ClientKey  string
	ServerName string
	ACLHeader  string
}

func loadTLSConfig(caCertPath, clientCert, clientKey, serverName string) (*tls.Config, error) {
	// Load CA certificate
	caCert, err := os.ReadFile(caCertPath)
	if err != nil {
		return nil, fmt.Errorf("failed to read CA certificate: %v", err)
	}

	caCertPool := x509.NewCertPool()
	if !caCertPool.AppendCertsFromPEM(caCert) {
		return nil, fmt.Errorf("failed to parse CA certificate")
	}

	// Load client certificate
	clientCertPair, err := tls.LoadX509KeyPair(clientCert, clientKey)
	if err != nil {
		return nil, fmt.Errorf("failed to load client certificate: %v", err)
	}

	return &tls.Config{
		RootCAs:      caCertPool,
		Certificates: []tls.Certificate{clientCertPair},
		ServerName:   serverName,
	}, nil
}

func createClientForEndpoint(config ServerConfig) (*clientv3.Client, error) {
	tlsConfig, err := loadTLSConfig(config.CACertPath, config.ClientCert, config.ClientKey, config.ServerName)
	if err != nil {
		return nil, fmt.Errorf("failed to create TLS config for %s: %v", config.Endpoint, err)
	}

	clientConfig := clientv3.Config{
		Endpoints:   []string{config.Endpoint},
		DialTimeout: 10 * time.Second,
		TLS:         tlsConfig,
	}

	return clientv3.New(clientConfig)
}

func addACLHeader(ctx context.Context, aclHeader string) context.Context {
	md := metadata.New(map[string]string{
		"acl": aclHeader,
	})
	return metadata.NewOutgoingContext(ctx, md)
}

func testEndpointWithACL(config ServerConfig) error {
	log.Printf("Testing endpoint: %s", config.Endpoint)

	// Create a dedicated client for this endpoint
	client, err := createClientForEndpoint(config)
	if err != nil {
		return fmt.Errorf("failed to create client for %s: %v", config.Endpoint, err)
	}
	defer client.Close()

	ctx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
	defer cancel()

	// Add ACL header for this specific endpoint
	ctx = addACLHeader(ctx, config.ACLHeader)

	// Test basic connectivity first
	log.Printf("Testing connectivity to %s...", config.Endpoint)
	status, err := client.Status(ctx, config.Endpoint)
	if err != nil {
		return fmt.Errorf("failed to get status from %s: %v", config.Endpoint, err)
	}
	log.Printf("Successfully connected to %s, version: %s", config.Endpoint, status.Version)

	// Create a unique key for this endpoint
	key := fmt.Sprintf("test-key-%s", config.Endpoint)
	value := fmt.Sprintf("test-value-%s-%d", config.Endpoint, time.Now().Unix())

	// Put a key-value pair
	_, err = client.Put(ctx, key, value)
	if err != nil {
		return fmt.Errorf("failed to put key-value to %s: %v", config.Endpoint, err)
	}
	fmt.Printf("Successfully put to %s: %s = %s\n", config.Endpoint, key, value)

	// Get the value
	resp, err := client.Get(ctx, key)
	if err != nil {
		return fmt.Errorf("failed to get key from %s: %v", config.Endpoint, err)
	}

	for _, kv := range resp.Kvs {
		fmt.Printf("Retrieved from %s: %s = %s\n", config.Endpoint, string(kv.Key), string(kv.Value))
	}

	return nil
}

func main() {
	// Configure each etcd server with different authorities and ACL headers
	serverConfigs := []ServerConfig{
		{
			Endpoint:   "etcd1:2379",
			CACertPath: "/tmp/certs/ca1.pem",
			ClientCert: "/tmp/certs/client1-cert.pem",
			ClientKey:  "/tmp/certs/client1-key.pem",
			ServerName: "etcd1",
			ACLHeader:  "etcd1-acl-token-12345",
		},
		{
			Endpoint:   "etcd2:2379",
			CACertPath: "/tmp/certs/ca2.pem",
			ClientCert: "/tmp/certs/client2-cert.pem",
			ClientKey:  "/tmp/certs/client2-key.pem",
			ServerName: "etcd2",
			ACLHeader:  "etcd2-acl-token-67890",
		},
		{
			Endpoint:   "etcd3:2379",
			CACertPath: "/tmp/certs/ca3.pem",
			ClientCert: "/tmp/certs/client3-cert.pem",
			ClientKey:  "/tmp/certs/client3-key.pem",
			ServerName: "etcd3",
			ACLHeader:  "etcd3-acl-token-abcde",
		},
	}

	log.Println("Starting etcd client tests with TLS and different authorities")

	// Test each endpoint individually with its specific ACL header
	for _, config := range serverConfigs {
		if err := testEndpointWithACL(config); err != nil {
			log.Printf("Error testing endpoint %s: %v", config.Endpoint, err)
		} else {
			log.Printf("Successfully tested endpoint: %s", config.Endpoint)
		}
		time.Sleep(1 * time.Second) // Small delay between tests
	}

	// Test cluster-wide operations using the first client
	if len(serverConfigs) > 0 {
		log.Println("Testing cluster-wide operations...")
		firstConfig := serverConfigs[0]
		client, err := createClientForEndpoint(firstConfig)
		if err != nil {
			log.Printf("Failed to create client for cluster operations: %v", err)
		} else {
			defer client.Close()

			ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
			defer cancel()

			// List cluster members
			memberResp, err := client.MemberList(ctx)
			if err != nil {
				log.Printf("Warning: Failed to list members: %v", err)
			} else {
				fmt.Println("\nCluster members:")
				for _, member := range memberResp.Members {
					fmt.Printf("  ID: %x, Name: %s, URLs: %v\n", member.ID, member.Name, member.ClientURLs)
				}
			}
		}
	}

	fmt.Println("\nTLS etcd client test with different authorities and ACL headers completed!")
}
